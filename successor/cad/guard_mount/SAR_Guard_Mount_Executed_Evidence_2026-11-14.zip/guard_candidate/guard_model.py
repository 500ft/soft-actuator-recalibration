"""Editable non-pressure concept geometry. No native application calls."""
import cadquery as cq
from guard_oracle import dimensions


def panel(spec):
    d=dimensions(spec)
    shape=cq.Workplane('XY').box(d['width'],d['thickness'],d['height'],centered=(True,True,False)).val()
    # Construct the feature pattern separately from the oracle's hole list.
    centers=[(sign*d['rail_spacing']/2,z,d['mount_hole_diameter'])
             for sign in [-1,1] for z in [d['mount_end_offset'],d['height']-d['mount_end_offset']]]
    centers.append((d['cable_hole_x'],d['cable_hole_z'],d['cable_hole_diameter']))
    for x,z,diameter in centers:
        tool=cq.Solid.makeCylinder(diameter/2,d['thickness'],
              cq.Vector(x,-d['thickness']/2,z),cq.Vector(0,1,0))
        shape=shape.cut(tool)
    return shape.clean()


def mounting_envelopes(spec):
    """Later assembly preview only; no selected slot/nut or qualified fixing."""
    d=dimensions(spec)
    length=d['shield_standoff']-d['thickness']/2-d['rail_depth']/2
    y_center=-(d['rail_depth']/2+d['shield_standoff']-d['thickness']/2)/2
    shapes=[]
    for x,local_z in [(sign*d['rail_spacing']/2,z) for sign in [-1,1]
                      for z in [d['mount_end_offset'],d['height']-d['mount_end_offset']]]:
        z=d['panel_bottom_global']+local_z
        block=cq.Workplane('XY').box(d['mount_block_width'],length,d['mount_block_height']).translate((x,y_center,z)).val()
        bore=cq.Solid.makeCylinder(d['mount_hole_diameter']/2,length,
               cq.Vector(x,-d['shield_standoff']+d['thickness']/2,z),cq.Vector(0,1,0))
        shapes.append(block.cut(bore).clean())
    return shapes
