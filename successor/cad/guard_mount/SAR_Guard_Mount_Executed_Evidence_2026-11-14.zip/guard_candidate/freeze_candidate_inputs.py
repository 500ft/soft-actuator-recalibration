"""Freeze inherited input bytes and independent algebra only; no CAD import."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,shutil
import guard_oracle

HERE=Path(__file__).resolve().parent
CAD=Path(r'C:\Users\Admin\Documents\ChatGPT\CAD_WORK_2026-11-08\repos\soft-actuator-recalibration\successor\cad')
STEP=Path(r'C:\Users\Admin\Desktop\soft-actuator-recalibration\03_EXPORTS\STEP\SAR-0109_01_SHIELD-TEST-FRAME.STEP')
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def choice(value,unit,source):
    return {'value':value,'unit':unit,'evidence_state':'provisional_design',
            'acquisition_route':'design_then_inspect','source':source}


def main():
    target=HERE/'guard_spec.json'
    assert not target.exists(),'Never overwrite the frozen candidate spec'
    sources=[CAD/'geometry.json',CAD/'build_concepts.py',CAD/'oracle.py',STEP]
    original=[dict(path=str(p),sha256=sha(p)) for p in sources]
    snapshot=HERE/'baseline_geometry_snapshot.json'
    assert not snapshot.exists()
    shutil.copyfile(CAD/'geometry.json',snapshot)
    spec=dict(status='CANDIDATE_PREPARED_NOT_EXECUTED',stage='CONCEPT',pn='SAR-0109',
        candidate_revision='02',material='Polycarbonate reference from prior concept; physical material selection HOLD',
        created_utc=datetime.now(timezone.utc).isoformat(),
        authority='Accepted pivot plan section 4C: guard mounting and cable passage; owner keeps successor research open',
        baseline_cad_directory=str(CAD),baseline_geometry=str(CAD/'geometry.json'),
        baseline_snapshot=str(snapshot),baseline_snapshot_sha256=sha(snapshot),
        frozen_sources=original,
        design_choices={
            'required_cable_radial_clearance':choice(2.0,'mm','New concept assembly allowance around the inherited conservative cable keep-out'),
            'cable_outside_reach':choice(8.0,'mm','New concept straight reach beyond the front of the guard; exit position and two bends unchanged'),
            'mount_nominal_fastener_diameter':choice(4.0,'mm','M4 design reference only; no hardware or rail nut selected'),
            'mount_hole_diameter':choice(4.5,'mm','Provisional through-clearance envelope for the M4 design reference'),
            'mount_edge_distance_factor':choice(1.5,'-','Provisional geometric center-to-edge screen in nominal fastener diameters; not a joint qualification'),
            'mount_end_offset':choice(50.0,'mm','New concept mount-hole center offset from each panel end'),
            'mount_block_width':choice(20.0,'mm','Provisional mounting envelope aligned to inherited 20 mm rail width'),
            'mount_block_height':choice(20.0,'mm','Provisional mounting envelope height; final bracket and slot hardware HOLD')},
        relations={
            'cable_hole_diameter':'inherited conservative keepout diameter + 2*required_cable_radial_clearance',
            'cable_hole_x':'baseline cable_exit_x - 2*baseline routing_radius',
            'cable_hole_z':'baseline chain-derived cell_bottom + cable_exit_z - panel_bottom_global',
            'routing_end_y':'-shield_standoff - thickness/2 - cable_outside_reach',
            'mount_holes':'X=+/-rail_spacing/2, local Z=mount_end_offset and height-mount_end_offset',
            'mount_envelopes':'Y from rail front (-rail_depth/2) to panel rear (-shield_standoff+thickness/2)'},
        inherited_gate_limits=dict(volume_anchor_absolute_mm3=1e-5,property_rtol=1e-7,
            property_atol=1e-6,hole_position_diameter_absolute_mm=1e-6,
            full_tensor='max(1e-4 mm5,8*ULP(largest expected diagonal)) + 1e-7*abs(expected term)'),
        pilot_scope='One nonpressure panel part, STEP readback, analytic moments, actual hole geometry and cable-reference clearance. No full legacy assembly or pressure parts.',
        mounting_scope='Four through-hole positions and matching standoff envelopes; actual extrusion T-slot/nuts/bolts/strain relief remain HOLD. No qualified fixing or containment claim.',
        native_application_authorized=False,pressure_rating_established=False,
        physical_work_authorized=False,public_release_authorized_by_this_candidate=False,
        execution_requires='Root review before one CAD pilot; first failed check stops; no automatic retry')
    target.write_text(json.dumps(spec,indent=2)+'\n')
    preview=dict(status='PREEXECUTION_ALGEBRA_ONLY_NO_CAD',dimensions=guard_oracle.dimensions(spec),
                 independent_panel=guard_oracle.panel(spec),
                 analytic_clearances=guard_oracle.analytic_clearances(spec),
                 original_sources_unchanged=all(sha(Path(x['path']))==x['sha256'] for x in original),
                 CAD_constructed=False,native_application_started=False)
    (HERE/'PREEXECUTION_ALGEBRA.json').write_text(json.dumps(preview,indent=2)+'\n')
    print(json.dumps(preview,indent=2))

if __name__=='__main__':main()
