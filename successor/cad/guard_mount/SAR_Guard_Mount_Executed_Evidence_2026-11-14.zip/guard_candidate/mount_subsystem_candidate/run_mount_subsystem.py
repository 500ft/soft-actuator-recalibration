"""One reviewed non-pressure guard/mount subsystem run; never retries or overwrites."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,copy,hashlib,itertools,json,sys,traceback
import numpy as np

HERE=Path(__file__).resolve().parent
PARENT=HERE.parent
sys.dont_write_bytecode=True
sys.path.insert(0,str(PARENT))
import guard_oracle
from run_one_guard_pilot import measure,tensor_terms,cylinder_faces
import mount_oracle

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def load(path):return json.loads(path.read_text())


def common_volume(a,b):
    x,y=a.BoundingBox(),b.BoundingBox()
    if any(getattr(x,axis+'min')>getattr(y,axis+'max')+1e-7 or
           getattr(y,axis+'min')>getattr(x,axis+'max')+1e-7 for axis in ['x','y','z']):return 0.
    return float(a.intersect(b).Volume())


def positive_pairs(shapes,threshold):
    result=[]
    for i,j in itertools.combinations(range(len(shapes)),2):
        volume=common_volume(shapes[i],shapes[j])
        if volume>threshold:result.append(dict(a_index=i,b_index=j,overlap_volume_mm3=volume))
    return result


def execute(output):
    if HERE not in output.parents:raise ValueError('Write only within mount_subsystem_candidate')
    spec=load(HERE/'subsystem_spec.json')
    for entry in spec['frozen_inputs']:
        assert sha(Path(entry['path']))==entry['sha256'],('Changed frozen input',entry['path'])
    if output.exists():raise FileExistsError('Fresh phase directory required; no overwrite or retry')
    output.mkdir(parents=True)
    state=dict(status='RUNNING_GUARD_MOUNT_SUBSYSTEM',stage='CONCEPT/HOLD',accepted=None,
        created_utc=datetime.now(timezone.utc).isoformat(),checks=[],automatic_retry=False,
        native_application_started=False,pressure_parts_rebuilt=False,
        subsystem_spec_sha256=sha(HERE/'subsystem_spec.json'),
        candidate_code_sha256={n:sha(HERE/n) for n in ['run_mount_subsystem.py','mount_oracle.py']})
    def save():(output/'result.json').write_text(json.dumps(state,indent=2)+'\n')
    def check(name,passed,**details):
        state['checks'].append(dict(name=name,passed=bool(passed),**details));save()
        if not passed:raise RuntimeError('First failed check: '+name)
    def properties(label,actual,expected):
        check(label+'_valid_single_solid',actual['valid'] and actual['solid_count']==1)
        error=actual['volume_mm3']-expected['volume_mm3']
        check(label+'_volume_anchor',abs(error)<1e-5,error_mm3=error,limit_mm3=1e-5)
        for key in ['centroid_mm','bbox_mm','principal_volume_moments_mm5']:
            check(label+'_'+key,np.allclose(actual[key],expected[key],rtol=1e-7,atol=1e-6),
                  measured=actual[key],expected=expected[key],rtol=1e-7,atol=1e-6)
        rule,terms=tensor_terms(actual,expected)
        state.setdefault('full_tensor_terms',{})[label]={'rule':rule,'terms':terms};save()
        for term in terms:check(f"{label}_tensor_{term['i']}{term['j']}",term['error_mm5']<=term['limit_mm5'],**term)
    def saved_holes(label,shape,expected):
        faces=cylinder_faces(shape)
        check(label+'_hole_count',len(faces)==len(expected),measured=len(faces),expected=len(expected))
        state.setdefault('saved_context_holes',{})[label]=faces;save()
        remaining=list(faces)
        for i,target in enumerate(expected):
            nearest=min(remaining,key=lambda x:np.linalg.norm(np.array(x['center_xz_mm'])-target['center_xz_mm']))
            remaining.remove(nearest)
            check(f'{label}_hole_{i}',
                np.allclose(nearest['center_xz_mm'],target['center_xz_mm'],rtol=0,atol=1e-6) and
                abs(nearest['diameter_mm']-target['diameter_mm'])<=1e-6 and
                np.allclose(np.abs(nearest['axis']),[0,1,0],rtol=0,atol=1e-9) and
                np.allclose(nearest['y_extents_mm'],target['y_extents_mm'],rtol=0,atol=1e-6),
                measured=nearest,expected=target)
    try:
        guard_spec=load(PARENT/'guard_spec.json');d=guard_oracle.dimensions(guard_spec)
        physical=spec['physical_acceptance']
        check('frozen_physical_criteria_match_accepted_guard',
              physical['minimum_cable_gap_mm']==d['required_cable_radial_clearance']==2. and
              physical['nominal_mount_fastener_diameter_mm']==d['mount_nominal_fastener_diameter']==4. and
              physical['mount_center_edge_factor']==d['mount_edge_distance_factor']==1.5 and
              physical['minimum_mount_center_edge_mm']==6.)
        pilot=load(Path(spec['accepted_guard_result']))
        check('prior_one_guard_pilot_passed',pilot['status']=='ONE_GUARD_CONCEPT_PILOT_CHECKS_PASS' and
              pilot.get('pilot_checks_passed') is True and all(c['passed'] for c in pilot['checks']))
        check('prior_guard_STEP_accepted_hash',sha(Path(spec['accepted_guard_STEP']))==pilot['step_sha256'])
        expected_blocks=mount_oracle.blocks(guard_spec)
        state['block_oracles']=expected_blocks;save()
        check('positive_block_geometry',all(x['volume_mm3']>0 and min(x['bbox_mm'])>0 for x in expected_blocks))
        import cadquery as cq
        import guard_model
        frame_shape=cq.importers.importStep(spec['baseline_frame_STEP']).val()
        originals=frame_shape.Solids()
        check('original_frame_24_solids',len(originals)==24,measured=len(originals))
        original_metrics=[measure(x) for x in originals]
        old_guard_center=[0,-d['shield_standoff'],d['panel_bottom_global']+d['height']/2]
        guard_indices=[i for i,m in enumerate(original_metrics)
                       if np.allclose(m['bbox_mm'],[d['width'],d['thickness'],d['height']],rtol=0,atol=1e-6)
                       and np.allclose(m['centroid_mm'],old_guard_center,rtol=0,atol=1e-6)]
        check('unique_original_guard_index',guard_indices==[14],measured=guard_indices,expected=[14])
        guard_index=guard_indices[0]
        rail_indices={}
        g=load(Path(guard_spec['baseline_snapshot']))
        rail_width=g['frame']['rail_section']['value'][0]
        for sign in [-1,1]:
            center=[sign*d['rail_spacing']/2,0,d['panel_bottom_global']+d['height']/2]
            found=[i for i,m in enumerate(original_metrics)
                   if np.allclose(m['bbox_mm'],[rail_width,d['rail_depth'],d['height']],rtol=0,atol=1e-6)
                   and np.allclose(m['centroid_mm'],center,rtol=0,atol=1e-6)]
            check(f'unique_rail_{sign}',len(found)==1,measured=found)
            rail_indices[sign]=found[0]
        threshold=spec['intersection_numerical_zero_mm3']
        baseline_pairs=positive_pairs(originals,threshold)
        baseline_ids={(x['a_index'],x['b_index']) for x in baseline_pairs}
        historical_ids={(x['a_index'],x['b_index']) for x in spec['historical_unresolved_interferences']}
        state['baseline_positive_interferences']=baseline_pairs
        state['baseline_solid_metrics']=original_metrics;save()
        check('baseline_existing_interference_set_unchanged',baseline_ids==historical_ids,
              measured=sorted(baseline_ids),historical=sorted(historical_ids))
        local_panel=cq.importers.importStep(spec['accepted_guard_STEP']).val()
        panel=local_panel.translate((0,-d['shield_standoff'],d['panel_bottom_global']))
        properties('placed_guard',measure(panel),mount_oracle.placed_panel(guard_spec))
        panel_faces=cylinder_faces(panel)
        blocks=guard_model.mounting_envelopes(guard_spec)
        check('four_mounting_envelopes_only',len(blocks)==4)
        restored_blocks=[]
        for index,(block,expected) in enumerate(zip(blocks,expected_blocks)):
            label=f'mount_{index+1}'
            properties(label+'_authored',measure(block),expected)
            path=output/(expected['name']+'_CONCEPT-HOLD.STEP')
            cq.exporters.export(block,str(path));restored=cq.importers.importStep(str(path)).val()
            properties(label+'_STEP',measure(restored),expected)
            hole_faces=cylinder_faces(restored)
            check(label+'_one_Y_through_hole',len(hole_faces)==1)
            hole=hole_faces[0];source=expected['hole']
            check(label+'_actual_hole_geometry',
                np.allclose(hole['center_xz_mm'],source['center_xz_mm'],rtol=0,atol=1e-6) and
                abs(hole['diameter_mm']-source['diameter_mm'])<=1e-6 and
                np.allclose(np.abs(hole['axis']),[0,1,0],rtol=0,atol=1e-9) and
                np.allclose(hole['y_extents_mm'],source['y_extents_mm'],rtol=0,atol=1e-6),
                measured=hole,expected=source)
            measured_bounds=restored.BoundingBox()
            x,z=hole['center_xz_mm']
            edge=min(x-measured_bounds.xmin,measured_bounds.xmax-x,
                     z-measured_bounds.zmin,measured_bounds.zmax-z)
            check(label+'_frozen_center_edge_rule',edge>=spec['physical_acceptance']['minimum_mount_center_edge_mm'],
                  measured_center_edge_mm=edge,required_mm=spec['physical_acceptance']['minimum_mount_center_edge_mm'])
            panel_hole=min(panel_faces,key=lambda f:np.linalg.norm(np.array(f['center_xz_mm'])-source['center_xz_mm']))
            check(label+'_axis_aligned_with_actual_panel_hole',
                np.allclose(panel_hole['center_xz_mm'],hole['center_xz_mm'],rtol=0,atol=1e-6) and
                abs(panel_hole['diameter_mm']-hole['diameter_mm'])<=1e-6 and
                np.allclose(np.abs(panel_hole['axis']),[0,1,0],rtol=0,atol=1e-9))
            rail=originals[rail_indices[expected['rail_sign']]]
            bound=restored.BoundingBox();rail_bound=rail.BoundingBox();panel_bound=panel.BoundingBox()
            check(label+'_endpoint_planes',abs(bound.ymax-rail_bound.ymin)<=1e-6 and abs(bound.ymin-panel_bound.ymax)<=1e-6,
                  block_y_bounds_mm=[bound.ymin,bound.ymax],rail_front_y_mm=rail_bound.ymin,panel_rear_y_mm=panel_bound.ymax)
            for contact_name,target in [('rail',rail),('panel',panel)]:
                gap=restored.distance(target);overlap=common_volume(restored,target)
                check(label+'_'+contact_name+'_nominal_tangency',gap<=1e-6 and overlap<=threshold,
                      distance_mm=gap,overlap_mm3=overlap,numerical_zero_mm3=threshold)
            restored_blocks.append(restored)
        candidate=list(originals);candidate[guard_index]=panel;candidate+=restored_blocks
        candidate_pairs=positive_pairs(candidate,threshold)
        candidate_ids={(x['a_index'],x['b_index']) for x in candidate_pairs}
        new_pairs=[x for x in candidate_pairs if (x['a_index'],x['b_index']) not in baseline_ids]
        state['candidate_positive_interferences']=candidate_pairs
        state['existing_unresolved_interferences']=baseline_pairs
        state['new_positive_interferences']=new_pairs;save()
        check('no_NEW_positive_interferences',not new_pairs,measured_new_pairs=new_pairs)
        check('existing_interferences_remain_explicit',candidate_ids==baseline_ids,
              existing_assembly_interference_free=False,disposition='Unresolved cell/stud overlaps; no whitelist or overall-assembly acceptance')
        for old in baseline_pairs:
            new=next(x for x in candidate_pairs if (x['a_index'],x['b_index'])==(old['a_index'],old['b_index']))
            check(f"unchanged_old_overlap_{old['a_index']}_{old['b_index']}",abs(new['overlap_volume_mm3']-old['overlap_volume_mm3'])<=threshold,
                  before_mm3=old['overlap_volume_mm3'],after_mm3=new['overlap_volume_mm3'])
        baseline_cad=Path(guard_spec['baseline_cad_directory']);sys.path.insert(0,str(baseline_cad))
        import build_concepts as baseline
        g=copy.deepcopy(g);g['cell']['routing_end_y']['value']=d['routing_end_y']
        cable,path=baseline.make_cable_keepout(g,guard_oracle.cell_bottom_from_baseline(g))
        gap=panel.distance(cable);overlap=common_volume(panel,cable)
        state['cable_guard_clearance']={'minimum_clearance_mm':gap,'overlap_mm3':overlap,
            'required_mm':spec['physical_acceptance']['minimum_cable_gap_mm'],'centerline_end_mm':path.Edges()[-1].endPoint().toTuple()};save()
        check('accepted_cable_gap_preserved',gap>=spec['physical_acceptance']['minimum_cable_gap_mm']-1e-6 and overlap<=threshold)
        cable_oracle=baseline.oracle.cable_geometry(g,guard_oracle.cell_bottom_from_baseline(g))
        check('inherited_cable_volume_oracle',abs(cable.Volume()-cable_oracle['keepout_volume_mm3'])<1e-5,
              measured_mm3=cable.Volume(),expected_mm3=cable_oracle['keepout_volume_mm3'],limit_mm3=1e-5)
        check('inherited_cable_centerline_oracle',abs(path.Length()-cable_oracle['centerline_length_mm'])<1e-6,
              measured_mm=path.Length(),expected_mm=cable_oracle['centerline_length_mm'],limit_mm=1e-6)
        for index,block in enumerate(restored_blocks):
            volume=common_volume(block,cable)
            check(f'mount_{index+1}_no_cable_interference',volume<=threshold,overlap_mm3=volume)
        context=cq.Compound.makeCompound(candidate)
        context_path=output/'SAR-GUARD-MOUNT-CONTEXT_CONCEPT-HOLD.STEP'
        cq.exporters.export(context,str(context_path))
        preview_parts=[panel]+[originals[rail_indices[x]] for x in [-1,1]]+restored_blocks+[cable]
        preview=cq.Compound.makeCompound(preview_parts)
        preview_path=output/'SAR-GUARD-MOUNT-SUBSYSTEM_WITH-CABLE-KEEPOUT_CONCEPT-HOLD.STEP'
        cq.exporters.export(preview,str(preview_path))
        recovered=cq.importers.importStep(str(context_path)).val().Solids()
        check('context_STEP_28_solids',len(recovered)==28,measured=len(recovered))
        expected_metrics=[measure(x) for x in candidate]
        recovered_metrics=[measure(x) for x in recovered]
        unmatched=list(range(len(recovered)));association=[]
        for index,expected in enumerate(expected_metrics):
            def cost(candidate_index):
                actual=recovered_metrics[candidate_index]
                return np.linalg.norm(np.array(actual['centroid_mm'])-expected['centroid_mm'])+abs(actual['volume_mm3']-expected['volume_mm3'])/max(1.,abs(expected['volume_mm3']))
            chosen=min(unmatched,key=cost);unmatched.remove(chosen)
            actual=recovered_metrics[chosen];association.append({'source_index':index,'readback_index':chosen})
            check(f'context_STEP_component_{index}',actual['valid'] and actual['solid_count']==1 and
                  all(np.allclose(actual[k],expected[k],rtol=1e-7,atol=1e-6)
                      for k in ['volume_mm3','centroid_mm','bbox_mm','principal_volume_moments_mm5']))
            if index==guard_index:
                oracle_panel=mount_oracle.placed_panel(guard_spec)
                properties('context_STEP_guard',actual,oracle_panel)
                hole_targets=[dict(center_xz_mm=[h['x'],h['z']],diameter_mm=h['diameter'],
                        axis=[0,1,0],y_extents_mm=[-d['shield_standoff']-d['thickness']/2,
                                                 -d['shield_standoff']+d['thickness']/2])
                              for h in oracle_panel['holes']]
                saved_holes('context_STEP_guard',recovered[chosen],hole_targets)
            if index>=24:
                properties(f'context_STEP_mount_{index-23}',actual,expected_blocks[index-24])
                saved_holes(f'context_STEP_mount_{index-23}',recovered[chosen],[expected_blocks[index-24]['hole']])
        state['context_STEP_component_association']=association
        preview_read=cq.importers.importStep(str(preview_path)).val().Solids()
        check('subsystem_STEP_8_solids',len(preview_read)==8,measured=len(preview_read))
        preview_metrics=[measure(x) for x in preview_read]
        preview_expected=[measure(x) for x in preview_parts]
        remaining=list(range(len(preview_read)));preview_association=[]
        for index,expected in enumerate(preview_expected):
            nearest=min(remaining,key=lambda i:np.linalg.norm(np.array(preview_metrics[i]['centroid_mm'])-expected['centroid_mm'])+
                        abs(preview_metrics[i]['volume_mm3']-expected['volume_mm3'])/max(1.,abs(expected['volume_mm3'])))
            remaining.remove(nearest);actual=preview_metrics[nearest];preview_association.append(nearest)
            check(f'subsystem_STEP_component_{index}',actual['valid'] and actual['solid_count']==1 and
                  all(np.allclose(actual[k],expected[k],rtol=1e-7,atol=1e-6)
                      for k in ['volume_mm3','centroid_mm','bbox_mm','principal_volume_moments_mm5']))
        preview_panel=preview_read[preview_association[0]];preview_cable=preview_read[preview_association[-1]]
        preview_gap=preview_panel.distance(preview_cable);preview_overlap=common_volume(preview_panel,preview_cable)
        check('saved_subsystem_STEP_cable_clearance',preview_gap>=spec['physical_acceptance']['minimum_cable_gap_mm']-1e-6 and preview_overlap<=threshold,
              measured_gap_mm=preview_gap,overlap_mm3=preview_overlap,
              frozen_required_mm=spec['physical_acceptance']['minimum_cable_gap_mm'])
        state['subsystem_STEP_component_association']=preview_association
        state['output_files']={str(p.name):sha(p) for p in output.glob('*.STEP')};save()
        for entry in spec['frozen_inputs']:
            check('source_unchanged_'+Path(entry['path']).name,sha(Path(entry['path']))==entry['sha256'])
        state.update(status='GUARD_MOUNT_SUBSYSTEM_CHECKS_PASS_EXISTING_ASSEMBLY_INTERFERENCES_UNRESOLVED',
            accepted=None,subsystem_checks_passed=True,assembly_interference_free=False,
            actual_rail_slot_or_fasteners_qualified=False,guard_containment_qualified=False,
            pressure_parts_rebuilt=False,pressure_parts_released=False,publication_authorized=False,
            scope='Guard/passage and mounting-envelope subsystem only. Imported legacy pressure components remain unchanged context; two cell/stud overlaps remain unresolved.')
        save();print(json.dumps(state,indent=2))
    except Exception as error:
        state.update(status='STOPPED_AT_FIRST_FAILED_CHECK',accepted=False,error=str(error),traceback=traceback.format_exc())
        save();raise


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True)
    execute(parser.parse_args().output.resolve())
