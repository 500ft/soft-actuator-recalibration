"""Independent block-minus-Y-bore properties, in global assembly axes; no CAD."""
from pathlib import Path
import math,sys
import numpy as np
PARENT=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(PARENT))
import guard_oracle


def blocks(guard_spec):
    d=guard_oracle.dimensions(guard_spec)
    width,height=d['mount_block_width'],d['mount_block_height']
    length=d['shield_standoff']-d['thickness']/2-d['rail_depth']/2
    y0=-d['shield_standoff']+d['thickness']/2
    y1=-d['rail_depth']/2
    radius=d['mount_hole_diameter']/2
    box_volume=width*length*height
    removed=math.pi*radius**2*length
    inertia=np.diag([box_volume*(length**2+height**2)/12,
                     box_volume*(width**2+height**2)/12,
                     box_volume*(width**2+length**2)/12])
    inertia-=np.diag([removed*(3*radius**2+length**2)/12,
                      removed*radius**2/2,
                      removed*(3*radius**2+length**2)/12])
    result=[]
    for sign in [-1,1]:
        for local_z in [d['mount_end_offset'],d['height']-d['mount_end_offset']]:
            x=sign*d['rail_spacing']/2;z=d['panel_bottom_global']+local_z
            result.append(dict(name=f'MOUNT-ENVELOPE-{len(result)+1:02d}',
                volume_mm3=box_volume-removed,centroid_mm=[x,(y0+y1)/2,z],
                bbox_mm=[width,length,height],central_tensor_mm5=inertia.tolist(),
                principal_volume_moments_mm5=np.linalg.eigvalsh(inertia).tolist(),
                hole=dict(center_xz_mm=[x,z],diameter_mm=2*radius,axis=[0,1,0],y_extents_mm=[y0,y1]),
                rail_sign=sign,rail_front_y_mm=y1,panel_rear_y_mm=y0,
                physical_fixing_qualified=False))
    return result


def placed_panel(guard_spec):
    result=guard_oracle.panel(guard_spec)
    d=guard_oracle.dimensions(guard_spec)
    result['centroid_mm']=(np.array(result['centroid_mm'])+
                            [0,-d['shield_standoff'],d['panel_bottom_global']]).tolist()
    for hole in result['holes']:hole['z']+=d['panel_bottom_global']
    return result
