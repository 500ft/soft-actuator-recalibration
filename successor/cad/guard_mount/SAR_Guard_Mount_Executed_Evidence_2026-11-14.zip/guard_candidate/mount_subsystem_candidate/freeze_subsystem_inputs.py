"""Prepare nominal phase inputs and a finite redrive proposal; no CAD imports."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,sys
HERE=Path(__file__).resolve().parent;PARENT=HERE.parent
sys.path.insert(0,str(PARENT))
import guard_oracle
import mount_oracle

FRAME=Path(r'C:\Users\Admin\Desktop\soft-actuator-recalibration\03_EXPORTS\STEP\SAR-0001_02_ASSEMBLY-BLOCKED-FORCE-TEST-RIG.STEP')
AUDIT=Path(r'C:\Users\Admin\Desktop\soft-actuator-recalibration\04_ANALYSIS\AUDIT_2026-11-08\assembly_clearance.json')
LEGACY_REDRIVE=Path(r'C:\Users\Admin\Documents\ChatGPT\CAD_WORK_2026-11-08\repos\soft-actuator-recalibration\successor\cad\redrive_concepts.py')
PILOT=PARENT/'pilot_20261114'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def load(path):return json.loads(path.read_text())


def main():
    assert not (HERE/'subsystem_spec.json').exists(),'Do not overwrite prepared phase inputs'
    guard=load(PARENT/'guard_spec.json');d=guard_oracle.dimensions(guard)
    pilot=load(PILOT/'result.json')
    step=PILOT/'SAR-0109_02_CONCEPT-GUARD-PILOT.STEP'
    assert pilot['status']=='ONE_GUARD_CONCEPT_PILOT_CHECKS_PASS' and pilot['pilot_checks_passed']
    assert pilot['accepted'] is None and all(x['passed'] for x in pilot['checks'])
    assert sha(step)==pilot['step_sha256']
    audit=load(AUDIT)['assemblies'][0]
    assert audit['assembly']=='SAR-0001' and audit['rev']=='02'
    unresolved=[x for x in audit['pairs_within_1mm'] if x['overlap_volume_mm3']>1e-6]
    assert {(x['a_index'],x['b_index']) for x in unresolved}=={(9,10),(9,11)}
    inputs=[FRAME,AUDIT,LEGACY_REDRIVE,PILOT/'result.json',step,
            PARENT/'guard_spec.json',PARENT/'guard_oracle.py',PARENT/'guard_model.py',
            PARENT/'run_one_guard_pilot.py',Path(guard['baseline_snapshot'])]
    inputs += [Path(x['path']) for x in guard['frozen_sources']]
    inputs=list(dict.fromkeys(inputs))
    spec=dict(status='PREPARED_NOT_EXECUTED',stage='CONCEPT/HOLD',
        created_utc=datetime.now(timezone.utc).isoformat(),
        baseline_frame_STEP=str(FRAME),accepted_guard_result=str(PILOT/'result.json'),accepted_guard_STEP=str(step),
        frozen_inputs=[dict(path=str(p),sha256=sha(p)) for p in inputs],
        historical_unresolved_interferences=unresolved,
        intersection_numerical_zero_mm3=1e-6,
        physical_acceptance={'minimum_cable_gap_mm':d['required_cable_radial_clearance'],
            'nominal_mount_fastener_diameter_mm':d['mount_nominal_fastener_diameter'],
            'mount_center_edge_factor':d['mount_edge_distance_factor'],
            'minimum_mount_center_edge_mm':d['mount_nominal_fastener_diameter']*d['mount_edge_distance_factor']},
        numerical_acceptance={'volume_absolute_mm3':1e-5,'property_rtol':1e-7,'property_atol':1e-6,
            'hole_and_contact_position_absolute_mm':1e-6,
            'tensor':'max(1e-4,8*ULP(largest expected diagonal))+1e-7*abs(expected term)'},
        first_failed_check_stops=True,automatic_retry=False,
        scope='One nominal subsystem run: accepted guard imported, four mounting envelopes authored, original frame imported as unchanged context. Pressure parts are not rebuilt or detailed.',
        overall_assembly_acceptance=False,
        mounting_qualification='HOLD: actual rail slots, nuts, screws, joint strength, guard containment and strain relief remain unqualified',
        other_assembly_issues='SAR-0003 tube/chamber/cap interferences remain outside this nominal subsystem and unchanged',
        root_review_required_before_execution=True)
    (HERE/'subsystem_spec.json').write_text(json.dumps(spec,indent=2)+'\n')
    preview=dict(status='PREEXECUTION_ALGEBRA_ONLY_NO_CAD',mount_blocks=mount_oracle.blocks(guard),
                 physical_acceptance=spec['physical_acceptance'],CAD_constructed=False)
    (HERE/'SUBSYSTEM_ALGEBRA.json').write_text(json.dumps(preview,indent=2)+'\n')
    g=load(Path(guard['baseline_snapshot']));cases=[]
    def add(source,path,targets,kind='geometry',method='multiply_0.99'):
        obj=guard if source=='guard_spec' else g
        old=obj
        for key in path:old=old[key]
        new=old*1.01 if method=='multiply_1.01' else old+0.5 if method=='add_0.5' else old*.99
        cases.append(dict(parameter_source=source,path=path,from_value=old,to_value=new,
                          change_method=method,role=kind,expected_affected_geometry=targets))
    for key in ['required_cable_radial_clearance','cable_outside_reach','mount_hole_diameter',
                'mount_end_offset','mount_block_width','mount_block_height']:
        add('guard_spec',['design_choices',key,'value'],
            {'required_cable_radial_clearance':['panel cable-hole diameter'],
             'cable_outside_reach':['cable reference terminal straight segment'],
             'mount_hole_diameter':['panel mount holes','mount envelope bores'],
             'mount_end_offset':['panel mount-hole Z positions','mount envelope Z positions'],
             'mount_block_width':['mount envelope X width'],
             'mount_block_height':['mount envelope Z height']}[key],
            kind='geometry_sizing_only_physical_gap_criterion_frozen' if key=='required_cable_radial_clearance' else 'geometry',
            method='multiply_1.01' if key=='required_cable_radial_clearance' else 'multiply_0.99')
    for key,targets in {
        'plate_width':['panel width'],
        'shield_thickness':['panel thickness','mount envelope Y length','cable terminal Y'],
        'rail_length':['panel height','top mount-hole Z','synthetic rail-reference height'],
        'rail_spacing':['mount-hole X','mount envelope X','synthetic rail-reference X'],
        'shield_standoff':['panel global Y','mount Y length','cable terminal Y'],
        'plate_thickness':['panel/rail-reference global Z','chain-derived global cable Z']}.items():
        add('baseline_geometry',['frame',key,'value'],targets)
    add('baseline_geometry',['frame','rail_section','value',0],['synthetic rail-reference width only'],kind='reference_geometry_only_no_guard_or_mount_change')
    add('baseline_geometry',['frame','rail_section','value',1],['mount Y length','synthetic rail front plane'])
    for group,key in [('frame','pin_from_plate'),('rod_end','centre_to_stud_tip'),
                      ('plug','mechanical_depth'),('plug','head_length'),('plug','grip_length'),
                      ('specimen','active_length'),('coupler','pin_spacing')]:
        add('baseline_geometry',[group,key,'value'],['chain-derived cable/guard-hole Z only; no pressure solid rebuilt'])
    add('baseline_geometry',['cell','eye_to_eye','value'],['chain-derived cable/guard-hole Z'],method='add_0.5')
    add('baseline_geometry',['cell','size','value',2],['chain-derived cable/guard-hole Z'])
    for key,targets in {
        'cable_exit_x':['cable reference X','guard cable-hole X'],
        'cable_exit_z':['cable reference Z','guard cable-hole Z'],
        'routing_radius':['cable reference bends','guard cable-hole X'],
        'routing_envelope_diameter':['cable reference diameter','guard cable-hole diameter'],
        'grommet_protrusion':['cable reference start/bend Y only'],
        'routing_stub':['cable reference first-straight/bend Y only']}.items():
        add('baseline_geometry',['cell',key,'value'],targets,
            kind='reference_geometry_only_no_guard_or_mount_change' if key in ['grommet_protrusion','routing_stub'] else 'geometry')
    add('baseline_geometry',['cell','size','value',1],['cable reference start/bend Y only'],kind='reference_geometry_only_no_guard_or_mount_change')
    excluded=[dict(source='guard_spec',path=['design_choices',key,'value'],
                   reason='Criterion only; freeze baseline M4 reference and edge screen, no CAD geometry redrive')
              for key in ['mount_nominal_fastener_diameter','mount_edge_distance_factor']]
    excluded.append(dict(source='baseline_geometry',path=['cell','cable_bend_radius','value'],
        reason='Vendor minimum is a fixed validity criterion; retain it unchanged instead of changing an acceptance bound'))
    proposal=dict(status='PROPOSED_ONLY_NO_REDRIVE_EXECUTOR_OR_CASE_RUN',case_count=len(cases),cases=cases,
        policy='One negative-one-percent case per governing float/list component as the original SAR policy; explicit documented exceptions only',
        exceptions={'required_cable_radial_clearance':'Treat as synthetic hole-sizing allowance: up1%; verifier retains baseline2mm physical minimum',
                    'cell.eye_to_eye':'Preserve original SAR +0.5mm exception'},
        excluded_fixed_criteria=excluded,
        all_physical_acceptance_frozen=spec['physical_acceptance'],
        all_numerical_acceptance_frozen=spec['numerical_acceptance'],
        nominal_legacy_frame_context='Original 24-solid STEP is nominal only; never reuse it as changed geometry in synthetic redrives',
        redrive_scope='New guard and mount envelopes plus matching altered rail/cable references only; no pressure solids or legacy full assembly rebuilt',
        cell_and_pressure_dimensions='Only algebraic chain-position dependencies are varied. This does not redrive or qualify the vendor cell or pressure parts.',
        reference_only_cases='Explicitly labeled; they change reference geometry, not a manufactured guard/mount component',
        overridden_input='Original cell.routing_end_y is superseded by the new terminal-clearance relation; no independent dead-parameter redrive',
        next_step='Root reviews and executes the single nominal mounting phase first. Do not build a broad redrive runner before that real first use.')
    (HERE/'REDRIVE_PROPOSAL.json').write_text(json.dumps(proposal,indent=2)+'\n')
    print(json.dumps({'status':spec['status'],'physical_acceptance':spec['physical_acceptance'],
                      'proposed_redrive_cases':len(cases),'excluded_fixed_criteria':len(excluded),'CAD_executed':False},indent=2))

if __name__=='__main__':main()
