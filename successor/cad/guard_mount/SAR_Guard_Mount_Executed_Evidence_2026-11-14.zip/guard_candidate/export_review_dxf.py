"""Export the accepted pilot's actual front face to a review-only mm DXF."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, math
import cadquery as cq
from cadquery.occ_impl.exporters.dxf import DxfDocument
import ezdxf
import numpy as np

HERE=Path(__file__).resolve().parent
PILOT=HERE/'pilot_20261114'
OUT=HERE/'review_dxf_20261114'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    result=json.loads((PILOT/'result.json').read_text())
    assert result['status']=='ONE_GUARD_CONCEPT_PILOT_CHECKS_PASS'
    assert all(c['passed'] for c in result['checks'])
    assert result['accepted'] is None
    source=PILOT/'SAR-0109_02_CONCEPT-GUARD-PILOT.STEP'
    before=sha(source)
    assert before==result['step_sha256']
    assert not OUT.exists(), 'Preserve any prior export attempt'
    OUT.mkdir()
    record=dict(status='EXPORTING_REVIEW_DXF',stage='CONCEPT/HOLD',accepted=None,
                fabrication_authorized=False,created_utc=datetime.now(timezone.utc).isoformat(),
                source_step=str(source),source_step_sha256=before,checks={})
    def save(): (OUT/'result.json').write_text(json.dumps(record,indent=2)+'\n')
    def check(name,value):
        record['checks'][name]=bool(value);save()
        if not value: raise RuntimeError('First failed DXF check: '+name)
    try:
        shape=cq.importers.importStep(str(source)).val()
        front=[f for f in shape.Faces() if f.geomType()=='PLANE' and
               np.allclose(f.normalAt().toTuple(),[0,-1,0],rtol=0,atol=1e-9)]
        check('one_actual_front_face',len(front)==1)
        face=front[0].rotate((0,0,0),(1,0,0),-90)
        face=face.translate((0,0,-face.Center().z))
        check('front_face_planar_XY',face.BoundingBox().zlen<1e-6)
        target=OUT/'SAR-0109_02_CONCEPT-GUARD-PILOT.DXF'
        doc=DxfDocument(doc_units=4,metadata={'stage':'CONCEPT/HOLD','release':'NOT FOR FABRICATION'})
        doc.add_shape(face)
        doc.document.saveas(str(target))
        restored=ezdxf.readfile(target);entities=list(restored.modelspace())
        check('millimetre_document_units',restored.units==4)
        circles=[e for e in entities if e.dxftype()=='CIRCLE']
        lines=[e for e in entities if e.dxftype()=='LINE']
        check('only_five_circles_and_four_lines',len(circles)==5 and len(lines)==4 and len(entities)==9)
        expected=result['independent_oracle']
        measured=[]
        for circle in circles:
            point=circle.ocs().to_wcs(circle.dxf.center)
            measured.append(dict(x=float(point.x),z=float(point.y),diameter=2*float(circle.dxf.radius),
                                 plane_z=float(point.z)))
        measured.sort(key=lambda h:(h['x'],h['z']))
        holes=sorted(expected['holes'],key=lambda h:(h['x'],h['z']))
        check('all_actual_DXF_hole_centres_diameters',all(
            abs(m[k]-e[k])<=1e-6 for m,e in zip(measured,holes) for k in ['x','z','diameter']))
        check('all_circles_on_zero_plane',all(abs(m['plane_z'])<=1e-6 for m in measured))
        ends=np.array([[float(p.x),float(p.y),float(p.z)] for line in lines
                       for p in [line.dxf.start,line.dxf.end]])
        width,height=expected['bbox_mm'][0],expected['bbox_mm'][2]
        corners=[(-width/2,0),(width/2,0),(-width/2,height),(width/2,height)]
        counts=[sum(np.linalg.norm(p[:2]-corner)<=1e-6 for p in ends) for corner in corners]
        check('closed_rectangle_corners_and_plane',counts==[2]*4 and np.max(np.abs(ends[:,2]))<=1e-6)
        lengths=[(line.dxf.end-line.dxf.start).magnitude for line in lines]
        check('rectangle_side_lengths',np.allclose(sorted(lengths),sorted([width,width,height,height]),rtol=0,atol=1e-6))
        removed=[math.pi*(h['diameter']/2)**2 for h in measured]
        area=width*height-sum(removed)
        centroid=[-sum(a*h['x'] for a,h in zip(removed,measured))/area,
                  (width*height*height/2-sum(a*h['z'] for a,h in zip(removed,measured)))/area]
        record.update(hole_entities=measured,net_area_mm2=area,area_centroid_xz_mm=centroid,
                      DXF_sha256=sha(target),source_STEP_unchanged=sha(source)==before)
        check('net_area_matches_independent_panel',abs(area-expected['area_mm2'])<=1e-6)
        check('area_centroid_matches_independent_panel',np.allclose(centroid,np.array(expected['centroid_mm'])[[0,2]],rtol=0,atol=1e-6))
        check('source_STEP_unchanged',sha(source)==before)
        record['status']='REVIEW_DXF_EXPORT_AND_READBACK_PASS';save()
        print(json.dumps(record,indent=2))
    except Exception as error:
        record.update(status='STOPPED_AT_FIRST_FAILED_CHECK',error=str(error),automatic_retry=False);save();raise

if __name__=='__main__': main()
