"""Independent box-minus-through-cylinders algebra. No CAD imports."""
import math
import json
from pathlib import Path
import numpy as np


def dimensions(spec):
    g=json.loads(Path(spec['baseline_snapshot']).read_text())
    v=lambda group,key:g[group][key]['value']
    d={key:item['value'] for key,item in spec['design_choices'].items()}
    d.update(width=v('frame','plate_width'),thickness=v('frame','shield_thickness'),
             height=v('frame','rail_length'),rail_spacing=v('frame','rail_spacing'),
             rail_depth=v('frame','rail_section')[1],
             panel_bottom_global=v('frame','plate_thickness'),
             shield_standoff=v('frame','shield_standoff'),
             cable_keepout_diameter=v('cell','routing_envelope_diameter'))
    d['cable_hole_diameter']=d['cable_keepout_diameter']+2*d['required_cable_radial_clearance']
    d['cable_hole_x']=v('cell','cable_exit_x')-2*v('cell','routing_radius')
    d['cable_hole_z']=cell_bottom_from_baseline(g)+v('cell','cable_exit_z')-d['panel_bottom_global']
    d['routing_end_y']=-d['shield_standoff']-d['thickness']/2-d['cable_outside_reach']
    return d


def holes(spec):
    d = dimensions(spec)
    mount = [{'kind':'mount', 'x':sign*d['rail_spacing']/2,
              'z':z, 'diameter':d['mount_hole_diameter']}
             for sign in [-1,1] for z in [d['mount_end_offset'],
                                         d['height']-d['mount_end_offset']]]
    return mount + [{'kind':'cable', 'x':d['cable_hole_x'],
                     'z':d['cable_hole_z'], 'diameter':d['cable_hole_diameter']}]


def transport(volume, offset):
    return volume*(np.dot(offset,offset)*np.eye(3)-np.outer(offset,offset))


def panel(spec):
    d=dimensions(spec); width,thickness,height=d['width'],d['thickness'],d['height']
    box_volume=width*thickness*height
    entries=[(box_volume,np.array([0.,0.,height/2]),
              np.diag([box_volume*(thickness**2+height**2)/12,
                       box_volume*(width**2+height**2)/12,
                       box_volume*(width**2+thickness**2)/12]))]
    for hole in holes(spec):
        radius=hole['diameter']/2; volume=math.pi*radius**2*thickness
        tensor=np.diag([volume*(3*radius**2+thickness**2)/12,
                        volume*radius**2/2,
                        volume*(3*radius**2+thickness**2)/12])
        entries.append((-volume,np.array([hole['x'],0.,hole['z']]),-tensor))
    volume=sum(v for v,_,_ in entries)
    centroid=sum(v*c for v,c,_ in entries)/volume
    inertia=sum(t+transport(v,c-centroid) for v,c,t in entries)
    return {'volume_mm3':volume,'area_mm2':volume/thickness,
            'centroid_mm':centroid.tolist(),'bbox_mm':[width,thickness,height],
            'central_tensor_mm5':inertia.tolist(),
            'principal_volume_moments_mm5':np.linalg.eigvalsh(inertia).tolist(),
            'holes':holes(spec)}


def analytic_clearances(spec):
    d=dimensions(spec); hs=holes(spec)
    edge={f"{h['kind']}_{i}":min(d['width']/2-abs(h['x']),h['z'],d['height']-h['z'])-h['diameter']/2
          for i,h in enumerate(hs)}
    separation=min(math.hypot(a['x']-b['x'],a['z']-b['z'])-(a['diameter']+b['diameter'])/2
                   for i,a in enumerate(hs) for b in hs[i+1:])
    return {'hole_edge_ligaments_mm':edge,'minimum_hole_to_hole_ligament_mm':separation,
            'cable_radial_clearance_mm':(d['cable_hole_diameter']-d['cable_keepout_diameter'])/2,
            'mount_nominal_center_edge_distance_mm':min((d['width']-d['rail_spacing'])/2,d['mount_end_offset']),
            'mount_required_center_edge_distance_mm':d['mount_edge_distance_factor']*d['mount_nominal_fastener_diameter'],
            'mount_block_center_edge_distance_mm':min(d['mount_block_width'],d['mount_block_height'])/2,
            'mount_block_length_mm':d['shield_standoff']-d['thickness']/2-d['rail_depth']/2,
            'cable_end_beyond_guard_front_mm':-d['shield_standoff']-d['thickness']/2-d['routing_end_y']}


def cell_bottom_from_baseline(g):
    v=lambda group,key:g[group][key]['value']
    low_pin=v('frame','plate_thickness')+v('frame','pin_from_plate')
    fixed_face=low_pin+v('rod_end','centre_to_stud_tip')-v('plug','mechanical_depth')
    fixed_tip=fixed_face+v('plug','head_length')+v('plug','grip_length')
    free_end=fixed_tip+v('specimen','active_length')
    high_face=free_end+v('plug','grip_length')+v('plug','head_length')
    muscle_high_pin=high_face-v('plug','mechanical_depth')+v('rod_end','centre_to_stud_tip')
    cell_low_pin=muscle_high_pin+v('coupler','pin_spacing')
    return cell_low_pin+(v('cell','eye_to_eye')-v('cell','size')[2])/2
