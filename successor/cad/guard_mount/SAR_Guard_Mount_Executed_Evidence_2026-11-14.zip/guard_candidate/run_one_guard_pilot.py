"""One reviewed guard pilot. Stop first failure; never rebuild a failed case."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,copy,hashlib,importlib.util,json,math,sys,traceback
import numpy as np
import guard_oracle

HERE=Path(__file__).resolve().parent
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def measure(shape):
    from OCP.BRepGProp import BRepGProp
    from OCP.GProp import GProp_GProps
    props=GProp_GProps()
    estimate=BRepGProp.VolumeProperties_s(shape.wrapped,props,1e-9,True,False)
    matrix=props.MatrixOfInertia()
    tensor=np.array([[matrix.Value(i+1,j+1) for j in range(3)] for i in range(3)])
    center=props.CentreOfMass();bounds=shape.BoundingBox()
    return dict(volume_mm3=props.Mass(),centroid_mm=[center.X(),center.Y(),center.Z()],
                bbox_mm=[bounds.xlen,bounds.ylen,bounds.zlen],central_tensor_mm5=tensor.tolist(),
                principal_volume_moments_mm5=np.linalg.eigvalsh(tensor).tolist(),
                solid_count=len(shape.Solids()),valid=shape.isValid(),integration_estimate=estimate)


def cylinder_faces(shape):
    from OCP.BRepAdaptor import BRepAdaptor_Surface
    output=[]
    for face in shape.Faces():
        if face.geomType()!='CYLINDER':continue
        cylinder=BRepAdaptor_Surface(face.wrapped).Cylinder()
        axis=cylinder.Axis();point=axis.Location();direction=axis.Direction();bounds=face.BoundingBox()
        output.append(dict(center_xz_mm=[point.X(),point.Z()],diameter_mm=2*cylinder.Radius(),
             axis=[direction.X(),direction.Y(),direction.Z()],y_extents_mm=[bounds.ymin,bounds.ymax]))
    return sorted(output,key=lambda x:(x['center_xz_mm'][0],x['center_xz_mm'][1]))


def tensor_terms(measured,expected):
    tensor=np.array(expected['central_tensor_mm5']);actual=np.array(measured['central_tensor_mm5'])
    largest=float(np.max(np.abs(np.diag(tensor))))
    floor=max(1e-4,8*math.ulp(largest))
    terms=[dict(i=i,j=j,expected_mm5=float(tensor[i,j]),measured_mm5=float(actual[i,j]),
                limit_mm5=floor+1e-7*abs(float(tensor[i,j])),
                error_mm5=abs(float(actual[i,j]-tensor[i,j]))) for i in range(3) for j in range(3)]
    for term in terms:term['margin_mm5']=term['limit_mm5']-term['error_mm5']
    return {'formula':'max(1e-4,8*ULP(largest expected diagonal)) + 1e-7*abs(expected term)',
            'largest_expected_diagonal_mm5':largest,'absolute_component_mm5':floor},terms


def execute(output):
    spec=json.loads((HERE/'guard_spec.json').read_text())
    if HERE not in output.parents:raise ValueError('Write only to a new directory inside guard_candidate')
    assert sha(Path(spec['baseline_snapshot']))==spec['baseline_snapshot_sha256'],'Changed frozen baseline snapshot'
    for entry in spec['frozen_sources']:
        assert sha(Path(entry['path']))==entry['sha256'],('Changed original source',entry['path'])
    if output.exists():raise FileExistsError('Choose a fresh pilot directory; never overwrite/retry')
    output.mkdir(parents=True)
    state=dict(status='RUNNING_ONE_CONCEPT_GUARD_PILOT',stage='CONCEPT',accepted=None,
        native_application_started=False,pressure_rating_established=False,automatic_retry=False,
        created_utc=datetime.now(timezone.utc).isoformat(),checks=[],spec_sha256=sha(HERE/'guard_spec.json'),
        candidate_code_sha256={name:sha(HERE/name) for name in
              ['guard_model.py','guard_oracle.py','run_one_guard_pilot.py']})
    def save():
        (output/'result.json').write_text(json.dumps(state,indent=2)+'\n')
    def check(name,passed,**details):
        state['checks'].append(dict(name=name,passed=bool(passed),**details));save()
        if not passed:raise RuntimeError('First failed check: '+name)
    try:
        expected=guard_oracle.panel(spec);d=guard_oracle.dimensions(spec)
        clearance=guard_oracle.analytic_clearances(spec)
        state['independent_oracle']=expected;state['analytic_clearances']=clearance;save()
        check('positive_panel_and_hole_ligaments',expected['volume_mm3']>0 and
              min(clearance['hole_edge_ligaments_mm'].values())>0 and clearance['minimum_hole_to_hole_ligament_mm']>0)
        check('mount_center_edge_distance',clearance['mount_nominal_center_edge_distance_mm']>=clearance['mount_required_center_edge_distance_mm'])
        check('mount_envelope_center_edge_distance',clearance['mount_block_center_edge_distance_mm']>=clearance['mount_required_center_edge_distance_mm'])
        from guard_model import panel
        import cadquery as cq
        made=panel(spec);before=measure(made);state['authored_metrics']=before;save()
        check('valid_single_solid',before['valid'] and before['solid_count']==1)
        check('independent_volume_absolute_1e_minus_5_mm3',abs(before['volume_mm3']-expected['volume_mm3'])<1e-5,
              measured_error_mm3=before['volume_mm3']-expected['volume_mm3'],limit_mm3=1e-5)
        for key in ['centroid_mm','bbox_mm','principal_volume_moments_mm5']:
            check('oracle_'+key,np.allclose(before[key],expected[key],rtol=1e-7,atol=1e-6),
                  measured=before[key],expected=expected[key],rtol=1e-7,atol=1e-6)
        rule,terms=tensor_terms(before,expected)
        state['tensor_rule']=rule;state['authored_full_tensor_terms']=terms;save()
        for term in terms:check(f"authored_tensor_{term['i']}{term['j']}",term['error_mm5']<=term['limit_mm5'],**term)
        step=output/'SAR-0109_02_CONCEPT-GUARD-PILOT.STEP'
        cq.exporters.export(made,str(step));restored=cq.importers.importStep(str(step)).val()
        after=measure(restored);state['step_metrics']=after;state['step_sha256']=sha(step);save()
        check('reopened_step_valid_single_solid',after['valid'] and after['solid_count']==1)
        check('step_independent_volume_absolute_1e_minus_5_mm3',abs(after['volume_mm3']-expected['volume_mm3'])<1e-5,
              measured_error_mm3=after['volume_mm3']-expected['volume_mm3'],limit_mm3=1e-5)
        for key in ['volume_mm3','centroid_mm','bbox_mm','principal_volume_moments_mm5']:
            check('step_roundtrip_'+key,np.allclose(before[key],after[key],rtol=1e-7,atol=1e-6),
                  measured=after[key],expected=before[key],rtol=1e-7,atol=1e-6)
        for key in ['centroid_mm','bbox_mm','principal_volume_moments_mm5']:
            check('step_oracle_'+key,np.allclose(after[key],expected[key],rtol=1e-7,atol=1e-6),
                  measured=after[key],expected=expected[key],rtol=1e-7,atol=1e-6)
        step_rule,step_terms=tensor_terms(after,expected)
        assert step_rule==rule
        state['reopened_full_tensor_terms']=step_terms;save()
        for term in step_terms:check(f"reopened_tensor_{term['i']}{term['j']}",term['error_mm5']<=term['limit_mm5'],**term)
        faces=cylinder_faces(restored);state['reopened_hole_faces']=faces;save()
        holes=sorted(expected['holes'],key=lambda x:(x['x'],x['z']))
        check('five_actual_through_holes',len(faces)==len(holes))
        unmatched=list(faces)
        for i,hole in enumerate(holes):
            # Unique spatial association avoids relying on arbitrary STEP
            # face ordering or sub-tolerance axis-origin roundoff.
            face=min(unmatched,key=lambda f:np.linalg.norm(np.array(f['center_xz_mm'])-[hole['x'],hole['z']]))
            unmatched.remove(face)
            check(f'hole_{i}_position_axis_and_size',
                np.allclose(face['center_xz_mm'],[hole['x'],hole['z']],rtol=0,atol=1e-6) and
                abs(face['diameter_mm']-hole['diameter'])<=1e-6 and
                np.allclose(np.abs(face['axis']),[0,1,0],rtol=0,atol=1e-9) and
                np.allclose(face['y_extents_mm'],[-d['thickness']/2,d['thickness']/2],rtol=0,atol=1e-6),
                measured=face,expected=hole)
        # Only the existing cable/reference envelopes are added. No pressure
        # parts, full legacy assembly or proposed mount blocks are constructed.
        source=Path(spec['baseline_cad_directory']);sys.path.insert(0,str(source))
        import build_concepts as baseline
        g=json.loads(Path(spec['baseline_geometry']).read_text());g=copy.deepcopy(g)
        g['cell']['routing_end_y']['value']=d['routing_end_y']
        cell_bottom=guard_oracle.cell_bottom_from_baseline(g)
        cable,path=baseline.make_cable_keepout(g,cell_bottom)
        global_panel=restored.translate((0,-d['shield_standoff'],d['panel_bottom_global']))
        overlap=global_panel.intersect(cable).Volume();gap=global_panel.distance(cable)
        state['cable_guard_result']={'overlap_mm3':overlap,'minimum_clearance_mm':gap,
              'required_clearance_mm':d['required_cable_radial_clearance'],
              'centerline_start_mm':path.Edges()[0].startPoint().toTuple(),
              'centerline_end_mm':path.Edges()[-1].endPoint().toTuple(),
              'cell_bottom_mm':cell_bottom};save()
        check('cable_panel_no_interference',overlap<=1e-6,measured_overlap_mm3=overlap,limit_mm3=1e-6)
        check('cable_panel_minimum_clearance',gap>=d['required_cable_radial_clearance']-1e-6,
              measured_clearance_mm=gap,required_mm=d['required_cable_radial_clearance'],numerical_allowance_mm=1e-6)
        check('cable_end_outside_guard',clearance['cable_end_beyond_guard_front_mm']>=d['required_cable_radial_clearance'])
        for entry in spec['frozen_sources']:
            check('original_unchanged_'+Path(entry['path']).name,sha(Path(entry['path']))==entry['sha256'])
        state.update(status='ONE_GUARD_CONCEPT_PILOT_CHECKS_PASS',accepted=None,pilot_checks_passed=True,
                     mounting_interfaces='Four nominal panel mounting holes individually align with proposed envelope Y axes; standoff/rail-slot/hardware qualification HOLD',
                     pressure_parts_constructed=False,legacy_full_assembly_built=False,
                     design_release=False,containment_performance_qualified=False)
        save();print(json.dumps(state,indent=2))
    except Exception as exc:
        state.update(status='STOPPED_AT_FIRST_FAILED_CHECK',accepted=False,error=str(exc),traceback=traceback.format_exc())
        save();raise


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args();execute(args.output.resolve())
