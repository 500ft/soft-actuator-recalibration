"""Synthetic rail-box and inherited cable-path algebra; no CAD imports."""
import math
import numpy as np


def rail_boxes(g,d):
    width,depth=g['frame']['rail_section']['value']
    height=d['height'];volume=width*depth*height
    inertia=np.diag([volume*(depth**2+height**2)/12,
                     volume*(width**2+height**2)/12,
                     volume*(width**2+depth**2)/12])
    return [dict(volume_mm3=volume,centroid_mm=[sign*d['rail_spacing']/2,0,d['panel_bottom_global']+height/2],
                 bbox_mm=[width,depth,height],central_tensor_mm5=inertia.tolist(),
                 principal_volume_moments_mm5=np.linalg.eigvalsh(inertia).tolist()) for sign in [-1,1]]


def cable_path(g,cell_bottom,end_y):
    c=lambda key:g['cell'][key]['value']
    radius=c('routing_radius');outside_radius=c('routing_envelope_diameter')/2
    start_y=-c('size')[1]/2-c('grommet_protrusion')
    after_stub=start_y-c('routing_stub');end_bends=after_stub-2*radius
    length=c('routing_stub')+math.pi*radius+end_bends-end_y
    return dict(start_mm=[c('cable_exit_x'),start_y,cell_bottom+c('cable_exit_z')],
                end_mm=[c('cable_exit_x')-2*radius,end_y,cell_bottom+c('cable_exit_z')],
                centerline_length_mm=length,volume_mm3=math.pi*outside_radius**2*length,
                bend_radius_mm=radius,bend_count=2,source_minimum_bend_radius_mm=c('cable_bend_radius'))
