"""Freeze the already proposed thirty inputs and accepted nominal data. No CAD."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
HERE=Path(__file__).resolve().parent;PARENT=HERE.parent
MOUNTS=PARENT/'mount_subsystem_candidate'
NOMINAL=MOUNTS/'nominal_20261114'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def load(path):return json.loads(path.read_text())


def main():
    target=HERE/'redrive_spec.json'
    assert not target.exists(),'Never replace prepared redrive inputs'
    proposal_path=MOUNTS/'REDRIVE_PROPOSAL.json';proposal=load(proposal_path)
    nominal=load(NOMINAL/'result.json');mount_spec=load(MOUNTS/'subsystem_spec.json')
    assert nominal['status']=='GUARD_MOUNT_SUBSYSTEM_CHECKS_PASS_EXISTING_ASSEMBLY_INTERFERENCES_UNRESOLVED'
    assert nominal['subsystem_checks_passed'] and nominal['accepted'] is None
    assert all(x['passed'] for x in nominal['checks'])
    assert proposal['case_count']==len(proposal['cases'])==30
    assert proposal['all_physical_acceptance_frozen']==mount_spec['physical_acceptance']
    assert proposal['all_numerical_acceptance_frozen']==mount_spec['numerical_acceptance']
    excluded={(x['source'],tuple(x['path'])) for x in proposal['excluded_fixed_criteria']}
    assert all((x['parameter_source'],tuple(x['path'])) not in excluded for x in proposal['cases'])
    for entry in mount_spec['frozen_inputs']:
        assert sha(Path(entry['path']))==entry['sha256'],('Changed earlier frozen source',entry['path'])
    for name,digest in nominal['candidate_code_sha256'].items():
        assert sha(MOUNTS/name)==digest
    for name,digest in nominal['output_files'].items():assert sha(NOMINAL/name)==digest
    inputs=[proposal_path,NOMINAL/'result.json',MOUNTS/'subsystem_spec.json',
            MOUNTS/'run_mount_subsystem.py',MOUNTS/'mount_oracle.py',
            PARENT/'guard_model.py',PARENT/'guard_oracle.py',PARENT/'run_one_guard_pilot.py']
    inputs += [Path(x['path']) for x in mount_spec['frozen_inputs']]
    inputs += [NOMINAL/name for name in nominal['output_files']]
    inputs=list(dict.fromkeys(inputs))
    preview=NOMINAL/'SAR-GUARD-MOUNT-SUBSYSTEM_WITH-CABLE-KEEPOUT_CONCEPT-HOLD.STEP'
    record=dict(status='FINITE_30_CASE_REDRIVE_PREPARED_NOT_EXECUTED',stage='CONCEPT/HOLD',
        created_utc=datetime.now(timezone.utc).isoformat(),proposal_path=str(proposal_path),
        nominal_result=str(NOMINAL/'result.json'),nominal_subsystem_STEP=str(preview),
        frozen_inputs=[dict(path=str(p),sha256=sha(p)) for p in inputs],
        physical_acceptance=mount_spec['physical_acceptance'],numerical_acceptance=mount_spec['numerical_acceptance'],
        intersection_numerical_zero_mm3=mount_spec['intersection_numerical_zero_mm3'],
        exact_case_count=30,excluded_fixed_criteria=proposal['excluded_fixed_criteria'],
        change_policy='Exactly the proposal: one -1% float/list change, with its up1% hole-sizing and +0.5mm eye-spacing exceptions.',
        required_cable_radial_clearance_role='Synthetic hole-sizing allowance only; physical minimum remains baseline2mm in every verifier.',
        nominal_frame_policy='The original 24-solid frame is never imported for altered scenes. Only the accepted nominal eight-component preview supplies baseline affected-list metrics.',
        changed_scene_policy='Guard, four mount envelopes, matching two synthetic rail references and one cable reservation; no vendor cell or pressure part is rebuilt.',
        tensor_scope='Guard/mount/rail tensors use independent algebra; cable tensor is authored-to-STEP only, with independent cable volume/path/bend checks.',
        first_failed_check_stops=True,automatic_retry=False,root_review_required_before_execution=True,
        cases_run=0,CAD_executed=False,native_application_started=False,
        broader_fixture_acceptance=False,physical_qualification=False)
    target.write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps({'status':record['status'],'case_count':record['exact_case_count'],
                      'frozen_inputs':len(inputs),'CAD_executed':False},indent=2))

if __name__=='__main__':main()
