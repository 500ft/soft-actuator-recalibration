"""Exactly the reviewed finite guard/mount cases. First failed check stops."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,copy,hashlib,itertools,json,sys,traceback
import numpy as np

HERE=Path(__file__).resolve().parent;PARENT=HERE.parent
MOUNTS=PARENT/'mount_subsystem_candidate'
sys.dont_write_bytecode=True
sys.path.insert(0,str(PARENT));sys.path.insert(0,str(MOUNTS))
import guard_oracle,mount_oracle
from run_one_guard_pilot import measure,tensor_terms,cylinder_faces
from run_mount_subsystem import common_volume
import redrive_oracle

ROLES=['guard','rail_negative','rail_positive','mount_1','mount_2','mount_3','mount_4','cable_reservation']
FIELDS=['volume_mm3','centroid_mm','bbox_mm','principal_volume_moments_mm5']
def load(path):return json.loads(path.read_text())
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def leaf(obj,path):
    for key in path:obj=obj[key]
    return obj
def set_leaf(obj,path,value):
    for key in path[:-1]:obj=obj[key]
    obj[path[-1]]=value
def changed_leaves(a,b,path=()):
    if isinstance(a,dict):
        assert a.keys()==b.keys()
        return sum((changed_leaves(a[k],b[k],path+(k,)) for k in a),[])
    if isinstance(a,list):
        assert len(a)==len(b)
        return sum((changed_leaves(x,y,path+(i,)) for i,(x,y) in enumerate(zip(a,b))),[])
    return [list(path)] if a!=b else []


def execute(output):
    if HERE not in output.parents:raise ValueError('Fresh outputs must stay within redrive_candidate')
    spec=load(HERE/'redrive_spec.json');proposal=load(Path(spec['proposal_path']))
    for entry in spec['frozen_inputs']:
        assert sha(Path(entry['path']))==entry['sha256'],('Changed frozen input',entry['path'])
    assert proposal['case_count']==len(proposal['cases'])==30
    assert spec['physical_acceptance']==proposal['all_physical_acceptance_frozen']
    physical=spec['physical_acceptance'];numeric=spec['numerical_acceptance']
    assert numeric==proposal['all_numerical_acceptance_frozen']
    assert physical=={'minimum_cable_gap_mm':2.,'nominal_mount_fastener_diameter_mm':4.,
                     'mount_center_edge_factor':1.5,'minimum_mount_center_edge_mm':6.}
    assert numeric['volume_absolute_mm3']==1e-5 and numeric['property_rtol']==1e-7 and numeric['property_atol']==1e-6
    assert spec['intersection_numerical_zero_mm3']==1e-6
    nominal=load(Path(spec['nominal_result']))
    assert nominal['status']=='GUARD_MOUNT_SUBSYSTEM_CHECKS_PASS_EXISTING_ASSEMBLY_INTERFERENCES_UNRESOLVED'
    assert nominal['subsystem_checks_passed'] and nominal['accepted'] is None and all(x['passed'] for x in nominal['checks'])
    base_guard=load(PARENT/'guard_spec.json');base_g=load(Path(base_guard['baseline_snapshot']))
    assert output.exists() is False,'Never overwrite or resume a failed/partial finite run'
    output.mkdir(parents=True)
    summary=dict(status='RUNNING_FINITE_30_CASE_GUARD_MOUNT_REDRIVE',stage='CONCEPT/HOLD',accepted=None,
        created_utc=datetime.now(timezone.utc).isoformat(),planned_case_count=30,completed_case_count=0,cases=[],
        physical_criteria_frozen=physical,numerical_criteria_frozen=numeric,
        native_application_started=False,automatic_retry=False,pressure_parts_rebuilt=False,
        vendor_cell_solid_rebuilt=False,legacy_24_solid_frame_imported_for_changed_scene=False,
        redrive_spec_path=str(HERE/'redrive_spec.json'),redrive_spec_sha256=sha(HERE/'redrive_spec.json'),
        proposal_path=spec['proposal_path'],proposal_sha256=sha(Path(spec['proposal_path'])),
        code_sha256={name:sha(HERE/name) for name in ['run_guard_redrives.py','redrive_oracle.py']})
    def save_summary():(output/'result.json').write_text(json.dumps(summary,indent=2)+'\n')
    save_summary()
    import cadquery as cq
    import guard_model
    baseline_cad=Path(base_guard['baseline_cad_directory']);sys.path.insert(0,str(baseline_cad))
    import build_concepts as baseline
    nominal_preview=Path(spec['nominal_subsystem_STEP'])
    assert sha(nominal_preview)==nominal['output_files'][nominal_preview.name]
    nominal_solids=cq.importers.importStep(str(nominal_preview)).val().Solids()
    assert len(nominal_solids)==8
    association=nominal['subsystem_STEP_component_association']
    nominal_metrics={role:measure(nominal_solids[association[i]]) for i,role in enumerate(ROLES)}
    summary['nominal_reference_metrics']=nominal_metrics;save_summary()
    for ordinal,change in enumerate(proposal['cases'],1):
        summary['current_case']=ordinal;summary['current_parameter']=change;save_summary()
        folder=output/f'{ordinal:02d}';folder.mkdir()
        state=dict(status='RUNNING_ONE_SYNTHETIC_REDRIVE',stage='CONCEPT/HOLD',accepted=None,
                   case_number=ordinal,parameter=change,checks=[],physical_criteria_frozen=physical,
                   original_physical_inputs_changed=False,pressure_solids_built=False)
        def save_case():(folder/'result.json').write_text(json.dumps(state,indent=2)+'\n')
        def check(name,passed,**details):
            state['checks'].append(dict(name=name,passed=bool(passed),**details));save_case()
            if not passed:raise RuntimeError('First failed check: '+name)
        def properties(label,actual,expected,tensor=True):
            check(label+'_valid_single_solid',actual['valid'] and actual['solid_count']==1)
            check(label+'_volume_anchor',abs(actual['volume_mm3']-expected['volume_mm3'])<1e-5,
                  error_mm3=actual['volume_mm3']-expected['volume_mm3'],limit_mm3=1e-5)
            for key in ['centroid_mm','bbox_mm','principal_volume_moments_mm5']:
                check(label+'_'+key,np.allclose(actual[key],expected[key],rtol=1e-7,atol=1e-6),
                      measured=actual[key],expected=expected[key],rtol=1e-7,atol=1e-6)
            if tensor:
                rule,terms=tensor_terms(actual,expected)
                state.setdefault('full_tensor_terms',{})[label]={'rule':rule,'terms':terms};save_case()
                for term in terms:check(f"{label}_tensor_{term['i']}{term['j']}",term['error_mm5']<=term['limit_mm5'],**term)
        def holes(label,shape,expected):
            faces=cylinder_faces(shape)
            check(label+'_hole_count',len(faces)==len(expected),measured=len(faces),expected=len(expected))
            state.setdefault('saved_hole_faces',{})[label]=faces;save_case()
            remaining=list(faces)
            for index,target in enumerate(expected):
                nearest=min(remaining,key=lambda face:np.linalg.norm(np.array(face['center_xz_mm'])-target['center_xz_mm']))
                remaining.remove(nearest)
                check(f'{label}_hole_{index}',np.allclose(nearest['center_xz_mm'],target['center_xz_mm'],rtol=0,atol=1e-6) and
                      abs(nearest['diameter_mm']-target['diameter_mm'])<=1e-6 and
                      np.allclose(np.abs(nearest['axis']),[0,1,0],rtol=0,atol=1e-9) and
                      np.allclose(nearest['y_extents_mm'],target['y_extents_mm'],rtol=0,atol=1e-6),
                      measured=nearest,expected=target)
        try:
            g=copy.deepcopy(base_g);guard=copy.deepcopy(base_guard)
            active=guard if change['parameter_source']=='guard_spec' else g
            source=base_guard if change['parameter_source']=='guard_spec' else base_g
            check('registered_from_value',leaf(active,change['path'])==change['from_value'])
            set_leaf(active,change['path'],change['to_value'])
            check('exact_one_registered_input_changed',changed_leaves(source,active)==[change['path']],
                  changed_paths=changed_leaves(source,active))
            check('other_input_source_unchanged',(g==base_g if change['parameter_source']=='guard_spec' else guard==base_guard))
            notice=dict(status='SYNTHETIC_LAYOUT_PARAMETER_CHECK_ONLY',changed_source=change['parameter_source'],
                        changed_numeric_path=change['path'],changed_numeric_value=change['to_value'],
                        evidence_labels='Original evidence labels are copied baseline provenance; the altered value is synthetic, not new vendor or measurement evidence.',
                        pressure_parts_built=False,vendor_cell_solid_built=False)
            g['_synthetic_layout_notice']=notice
            changed_snapshot=folder/'synthetic_geometry_inputs.json'
            changed_snapshot.write_text(json.dumps(g,indent=2)+'\n')
            guard['baseline_snapshot']=str(changed_snapshot);guard['baseline_snapshot_sha256']=sha(changed_snapshot)
            guard['_synthetic_layout_notice']=notice
            (folder/'synthetic_guard_spec.json').write_text(json.dumps(guard,indent=2)+'\n')
            d=guard_oracle.dimensions(guard)
            check('physical_criteria_not_taken_from_sizing_case',
                  physical['minimum_cable_gap_mm']==2. and physical['minimum_mount_center_edge_mm']==6. and
                  guard['design_choices']['mount_nominal_fastener_diameter']['value']==4. and
                  guard['design_choices']['mount_edge_distance_factor']['value']==1.5 and
                  g['cell']['cable_bend_radius']['value']==base_g['cell']['cable_bend_radius']['value'])
            state['resolved_synthetic_dimensions']=d
            state['sizing_allowance_vs_fixed_criterion']={'synthetic_hole_sizing_allowance_mm':d['required_cable_radial_clearance'],
                 'physical_minimum_cable_clearance_mm':physical['minimum_cable_gap_mm']};save_case()
            panel=guard_model.panel(guard).translate((0,-d['shield_standoff'],d['panel_bottom_global']))
            blocks=guard_model.mounting_envelopes(guard)
            width,depth=g['frame']['rail_section']['value']
            rails=[cq.Workplane('XY').box(width,depth,d['height'],centered=(True,True,False)).translate(
                   (sign*d['rail_spacing']/2,0,d['panel_bottom_global'])).val() for sign in [-1,1]]
            route_g=copy.deepcopy(g);route_g['cell']['routing_end_y']['value']=d['routing_end_y']
            cell_bottom=guard_oracle.cell_bottom_from_baseline(g)
            cable,path=baseline.make_cable_keepout(route_g,cell_bottom)
            scene=[panel]+rails+blocks+[cable]
            check('eight_subsystem_components_only',len(scene)==8 and len(blocks)==4)
            oracle_panel=mount_oracle.placed_panel(guard);oracle_blocks=mount_oracle.blocks(guard)
            oracle_rails=redrive_oracle.rail_boxes(g,d)
            cable_oracle=redrive_oracle.cable_path(g,cell_bottom,d['routing_end_y'])
            check('cable_path_start_end',np.allclose(path.Edges()[0].startPoint().toTuple(),cable_oracle['start_mm'],rtol=0,atol=1e-6) and
                  np.allclose(path.Edges()[-1].endPoint().toTuple(),cable_oracle['end_mm'],rtol=0,atol=1e-6))
            arcs=[edge for edge in path.Edges() if edge.geomType()=='CIRCLE']
            check('unchanged_cable_bend_validity',len(arcs)==2 and
                  all(abs(edge.radius()-cable_oracle['bend_radius_mm'])<=1e-6 and
                      edge.radius()>=base_g['cell']['cable_bend_radius']['value']-1e-6 for edge in arcs))
            check('cable_path_length',abs(path.Length()-cable_oracle['centerline_length_mm'])<1e-6,
                  measured_mm=path.Length(),expected_mm=cable_oracle['centerline_length_mm'])
            authored={role:measure(shape) for role,shape in zip(ROLES,scene)}
            state['authored_metrics']=authored
            state['cable_oracle_scope']='Analytic volume/path/endpoints/bend radii. Cable centroid/principals/tensor are authored-to-STEP checks only, not an analytic inertia or physical mass qualification.'
            cable_expected=copy.deepcopy(authored['cable_reservation']);cable_expected['volume_mm3']=cable_oracle['volume_mm3']
            expected=[oracle_panel]+oracle_rails+oracle_blocks+[cable_expected]
            state['independent_oracles']={role:value for role,value in zip(ROLES,expected) if role!='cable_reservation'}
            state['cable_analytic_oracle']=cable_oracle
            state['cable_authored_to_STEP_reference']=cable_expected;save_case()
            for index,(role,shape) in enumerate(zip(ROLES,scene)):
                if role=='cable_reservation':
                    check('cable_authored_valid_single_solid',authored[role]['valid'] and authored[role]['solid_count']==1)
                    check('cable_authored_volume_oracle',abs(authored[role]['volume_mm3']-cable_oracle['volume_mm3'])<1e-5,
                          measured_mm3=authored[role]['volume_mm3'],expected_mm3=cable_oracle['volume_mm3'])
                else:properties(role+'_authored',authored[role],expected[index])
                file=folder/(role+'_SYNTHETIC-REDRIVE.STEP')
                cq.exporters.export(shape,str(file));restored=cq.importers.importStep(str(file)).val()
                properties(role+'_STEP',measure(restored),expected[index])
                if role=='guard':
                    target=[dict(center_xz_mm=[h['x'],h['z']],diameter_mm=h['diameter'],axis=[0,1,0],
                        y_extents_mm=[-d['shield_standoff']-d['thickness']/2,-d['shield_standoff']+d['thickness']/2])
                            for h in oracle_panel['holes']]
                    holes(role+'_STEP',restored,target)
                elif role.startswith('mount_'):holes(role+'_STEP',restored,[oracle_blocks[int(role[-1])-1]['hole']])
            expected_holes=oracle_panel['holes']
            panel_bounds=panel.BoundingBox()
            panel_mounts=[h for h in expected_holes if h['kind']=='mount']
            for index,hole in enumerate(panel_mounts):
                edge=min(hole['x']-panel_bounds.xmin,panel_bounds.xmax-hole['x'],hole['z']-panel_bounds.zmin,panel_bounds.zmax-hole['z'])
                check(f'guard_mount_{index+1}_fixed_edge_criterion',edge>=physical['minimum_mount_center_edge_mm'],
                      measured_center_edge_mm=edge,frozen_required_mm=physical['minimum_mount_center_edge_mm'])
            for index,block in enumerate(blocks):
                bounds=block.BoundingBox();target=oracle_blocks[index]['hole'];x,z=target['center_xz_mm']
                edge=min(x-bounds.xmin,bounds.xmax-x,z-bounds.zmin,bounds.zmax-z)
                check(f'mount_{index+1}_fixed_edge_criterion',edge>=physical['minimum_mount_center_edge_mm'],
                      measured_center_edge_mm=edge,frozen_required_mm=physical['minimum_mount_center_edge_mm'])
                rail=rails[0 if oracle_blocks[index]['rail_sign']==-1 else 1]
                rb=rail.BoundingBox()
                check(f'mount_{index+1}_matching_synthetic_contact_planes',abs(bounds.ymin-panel_bounds.ymax)<=1e-6 and abs(bounds.ymax-rb.ymin)<=1e-6)
                for name,target_shape in [('guard',panel),('rail',rail)]:
                    check(f'mount_{index+1}_{name}_nominal_tangency',block.distance(target_shape)<=1e-6 and
                          common_volume(block,target_shape)<=spec['intersection_numerical_zero_mm3'])
            pairwise=[]
            for i,j in itertools.combinations(range(8),2):
                gap=scene[i].distance(scene[j]);overlap=common_volume(scene[i],scene[j])
                pairwise.append(dict(a=ROLES[i],b=ROLES[j],gap_mm=gap,overlap_mm3=overlap))
                check(f'no_component_overlap_{i}_{j}',overlap<=spec['intersection_numerical_zero_mm3'],
                      overlap_mm3=overlap,limit_mm3=spec['intersection_numerical_zero_mm3'])
            state['pairwise_clearances']=pairwise
            cable_gap=panel.distance(cable)
            check('fixed_two_mm_guard_cable_gap',cable_gap>=physical['minimum_cable_gap_mm']-1e-6,
                  measured_mm=cable_gap,frozen_required_mm=physical['minimum_cable_gap_mm'],numerical_allowance_mm=1e-6)
            for index,rail in enumerate(rails):check(f'cable_clear_of_rail_reference_{index}',rail.distance(cable)>0)
            check('terminal_run_beyond_front',-d['shield_standoff']-d['thickness']/2-path.Edges()[-1].endPoint().toTuple()[1]>=physical['minimum_cable_gap_mm'])
            scene_file=folder/'SUBSYSTEM_SYNTHETIC-REDRIVE.STEP'
            cq.exporters.export(cq.Compound.makeCompound(scene),str(scene_file))
            recovered=cq.importers.importStep(str(scene_file)).val().Solids()
            check('saved_subsystem_eight_solids',len(recovered)==8,measured=len(recovered))
            recovered_metrics=[measure(x) for x in recovered];unmatched=list(range(8));mapping=[]
            for index,role in enumerate(ROLES):
                expected_metric=authored[role]
                chosen=min(unmatched,key=lambda j:np.linalg.norm(np.array(recovered_metrics[j]['centroid_mm'])-expected_metric['centroid_mm'])+
                           abs(recovered_metrics[j]['volume_mm3']-expected_metric['volume_mm3'])/max(1.,abs(expected_metric['volume_mm3'])))
                unmatched.remove(chosen);mapping.append(chosen)
                properties(role+'_saved_scene',recovered_metrics[chosen],expected[index])
                if role=='guard':holes(role+'_saved_scene',recovered[chosen],target_guard_holes(oracle_panel,d))
                elif role.startswith('mount_'):holes(role+'_saved_scene',recovered[chosen],[oracle_blocks[int(role[-1])-1]['hole']])
            saved_gap=recovered[mapping[0]].distance(recovered[mapping[-1]])
            saved_overlap=common_volume(recovered[mapping[0]],recovered[mapping[-1]])
            check('saved_scene_fixed_two_mm_cable_gap',saved_gap>=physical['minimum_cable_gap_mm']-1e-6 and saved_overlap<=spec['intersection_numerical_zero_mm3'],
                  measured_gap_mm=saved_gap,overlap_mm3=saved_overlap,frozen_required_mm=physical['minimum_cable_gap_mm'])
            saved_scene=[recovered[index] for index in mapping]
            saved_pairs=[]
            for i,j in itertools.combinations(range(8),2):
                gap=saved_scene[i].distance(saved_scene[j]);overlap=common_volume(saved_scene[i],saved_scene[j])
                saved_pairs.append(dict(a=ROLES[i],b=ROLES[j],gap_mm=gap,overlap_mm3=overlap))
                check(f'saved_scene_no_component_overlap_{i}_{j}',overlap<=spec['intersection_numerical_zero_mm3'],
                      overlap_mm3=overlap,limit_mm3=spec['intersection_numerical_zero_mm3'])
            state['saved_scene_pairwise_clearances']=saved_pairs
            saved_panel=saved_scene[0];saved_panel_bounds=saved_panel.BoundingBox()
            for index,block in enumerate(saved_scene[3:7]):
                rail=saved_scene[1 if oracle_blocks[index]['rail_sign']==-1 else 2]
                bounds=block.BoundingBox();rb=rail.BoundingBox();actual_hole=cylinder_faces(block)[0]
                x,z=actual_hole['center_xz_mm']
                edge=min(x-bounds.xmin,bounds.xmax-x,z-bounds.zmin,bounds.zmax-z)
                check(f'saved_mount_{index+1}_fixed_edge_rule',edge>=physical['minimum_mount_center_edge_mm'],
                      measured_center_edge_mm=edge,frozen_required_mm=physical['minimum_mount_center_edge_mm'])
                check(f'saved_mount_{index+1}_contact_planes',abs(bounds.ymin-saved_panel_bounds.ymax)<=1e-6 and abs(bounds.ymax-rb.ymin)<=1e-6)
                for label,target in [('guard',saved_panel),('rail',rail)]:
                    check(f'saved_mount_{index+1}_{label}_tangency',block.distance(target)<=1e-6)
            for index,hole in enumerate(cylinder_faces(saved_panel)):
                if abs(hole['diameter_mm']-d['mount_hole_diameter'])>1e-6:continue
                x,z=hole['center_xz_mm']
                edge=min(x-saved_panel_bounds.xmin,saved_panel_bounds.xmax-x,z-saved_panel_bounds.zmin,saved_panel_bounds.zmax-z)
                check(f'saved_guard_mount_{index+1}_fixed_edge_rule',edge>=physical['minimum_mount_center_edge_mm'],
                      measured_center_edge_mm=edge,frozen_required_mm=physical['minimum_mount_center_edge_mm'])
            affected=[role for role in ROLES if any(not np.allclose(nominal_metrics[role][key],authored[role][key],rtol=1e-10,atol=1e-7) for key in FIELDS)]
            check('registered_parameter_affects_subsystem_geometry',bool(affected),affected_geometry=affected,
                  original_SAR_affected_list_rtol=1e-10,original_SAR_affected_list_atol=1e-7)
            made=[role for role in affected if role=='guard' or role.startswith('mount_')]
            if change['role']=='reference_geometry_only_no_guard_or_mount_change':
                check('reference_only_case_not_claimed_as_made_part_change',not made,affected_made_parts=made)
            state.update(status='SYNTHETIC_REDRIVE_CASE_CHECKS_PASS',accepted=None,case_checks_passed=True,
                affected_geometry=affected,affected_made_part_geometry=made,
                affected_reference_geometry=[role for role in affected if role not in made],
                physical_guard_cable_gap_mm=saved_gap,
                output_STEP_sha256={p.name:sha(p) for p in folder.glob('*.STEP')},
                saved_scene_component_mapping=mapping)
            save_case()
            summary['cases'].append(dict(case_number=ordinal,parameter=change,passed=True,
                result=str(folder/'result.json'),affected_geometry=affected,physical_guard_cable_gap_mm=saved_gap))
            summary['completed_case_count']=ordinal;save_summary()
            print(json.dumps({'case':ordinal,'status':state['status'],'affected_geometry':affected}),flush=True)
        except Exception as error:
            state.update(status='STOPPED_AT_FIRST_FAILED_CHECK',accepted=False,error=str(error),traceback=traceback.format_exc())
            save_case();summary.update(status='STOPPED_AT_FIRST_FAILED_CHECK',failed_case=ordinal,error=str(error))
            summary['cases'].append(dict(case_number=ordinal,parameter=change,passed=False,result=str(folder/'result.json')))
            save_summary();raise
    for entry in spec['frozen_inputs']:
        if sha(Path(entry['path']))!=entry['sha256']:
            summary.update(status='STOPPED_AT_FIRST_FAILED_CHECK',error='Changed frozen input after finite run: '+entry['path'])
            save_summary();raise RuntimeError(summary['error'])
    summary.update(status='FINITE_30_GUARD_MOUNT_REDRIVE_CHECKS_PASS',accepted=None,all_registered_cases_passed=True,
                   all_original_inputs_unchanged=True,physical_criteria_changed=False,numerical_limits_changed=False,
                   overall_fixture_interference_free=False,
                   scope='New guard/mount geometry and matching synthetic reference envelopes only. Existing fixture/pneumatic issues and physical interfaces remain outside this finite parametric check.')
    save_summary();print(json.dumps({'status':summary['status'],'case_count':summary['completed_case_count']}),flush=True)


def target_guard_holes(oracle,d):
    return [dict(center_xz_mm=[h['x'],h['z']],diameter_mm=h['diameter'],axis=[0,1,0],
                 y_extents_mm=[-d['shield_standoff']-d['thickness']/2,-d['shield_standoff']+d['thickness']/2]) for h in oracle['holes']]


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args();destination=args.output.resolve();existing_destination=destination.exists()
    try:execute(destination)
    except Exception as error:
        result=destination/'result.json'
        if not existing_destination and HERE in destination.parents and result.exists():
            state=load(result)
            if state['status'].startswith('RUNNING'):
                state.update(status='STOPPED_AT_FIRST_FAILED_CHECK',error=str(error),traceback=traceback.format_exc())
                result.write_text(json.dumps(state,indent=2)+'\n')
        raise
